package org.launchcode.lesson6.studio.question;

public enum QuestionType {
    MULTI_CHOICE,
    CHECKBOX,
    TRUE_OR_FALSE
}
