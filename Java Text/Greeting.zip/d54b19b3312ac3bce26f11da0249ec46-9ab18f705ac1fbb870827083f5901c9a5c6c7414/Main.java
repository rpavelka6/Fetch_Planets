package org.launchcode.inheritance.examples;

public class Main {

    public static void main (String[] args) {
        Greeting greeting = new Greeting(false, "English");

        System.out.println(greeting.getMorningMessage());
    }
}